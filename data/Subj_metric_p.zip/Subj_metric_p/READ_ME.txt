I simply remove the first row (‘x') of the original data, and
tranfer all of them to .npy file (in numpy ndarray)