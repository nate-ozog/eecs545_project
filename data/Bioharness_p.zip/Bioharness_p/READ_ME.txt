I simply remove the first row (field) and the first column (user id) of the original data, and
tranfer all of them to .npy file (in numpy ndarray)