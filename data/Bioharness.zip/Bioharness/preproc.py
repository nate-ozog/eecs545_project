# -*- coding: utf-8 -*-
"""
Created on Thu Mar  4 12:55:00 2021

@author: xinyu
"""

import csv
import numpy as np
import pandas as pd 

fn = "Bio_SJ1.csv"

rows = [] 
with open(fn, 'r') as csvfile: 
    csvreader = csv.reader(csvfile, delimiter=';')     
    fields = next(csvreader) 
    for row in csvreader: 
        ele = np.array(row[1:])
        rows.append(ele)
    data = np.vstack(rows)

    print(data.shape)
    
# can be used to generate a csv file

# pd.DataFrame(data).to_csv("test.csv", header=None, index=None)

np.save('Bio_SJ1_p.npy', data)
